from aiogram import Router, types, F
from aiogram.filters import Command
from config import ADMIN_ID
from database.db import DataBase

router = Router()

@router.message(Command("admin"))
async def admin_panel(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        await message.answer("⛔️ Доступ запрещён.")
        return

    await message.answer(
        "👑 <b>Панель администратора активна</b>\n\n"
        "Доступные команды:\n"
        "/access — открыть WebApp без проверок\n"
        "/help — помощь\n"
        "/stats — статистика\n"
        "/send — сделать рассылку",
        parse_mode="HTML"
    )


@router.message(Command("access"))
async def access_command(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    keyboard = types.InlineKeyboardMarkup(
        inline_keyboard=[
            [types.InlineKeyboardButton(
                text="🔓 Получить сигнал",
                web_app=types.WebAppInfo(url="https://blance18.github.io/signalflowcess/")
            )]
        ]
    )
    await message.answer("🔓 Доступ к WebApp без ограничений:", reply_markup=keyboard)


@router.message(Command("help"))
async def help_command(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    await message.answer(
        "🛠 <b>Доступные команды:</b>\n"
        "/access — тест WebApp без регистрации\n"
        "/admin — панель администратора\n"
        "/help — показать это сообщение\n"
        "/stats — статистика\n"
        "/send — рассылка",
        parse_mode="HTML"
    )


@router.message(Command("stats"))
async def stats_command(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    total = await DataBase.get_users_count()
    verified = await DataBase.get_verified_users_count()
    await message.answer(
        f"📊 <b>Статистика</b>\n\n"
        f"👥 Всего пользователей: <b>{total}</b>\n"
        f"✅ Зарегистрировано по реф. ссылке: <b>{verified}</b>",
        parse_mode="HTML"
    )


@router.message(Command("send"))
async def ask_broadcast_text(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return
    await message.answer("✍️ Введите текст для рассылки всем пользователям.")


@router.message(F.text & F.from_user.id == ADMIN_ID)
async def handle_broadcast(message: types.Message):
    if message.text.startswith("/"):
        return  # игнорируем другие команды

    users = await DataBase.get_users()
    success = 0
    for row in users:
        user_id = row[1]
        try:
            await message.bot.send_message(chat_id=user_id, text=message.text)
            success += 1
        except:
            pass
    await message.answer(f"📬 Рассылка завершена. Успешно отправлено: {success} сообщений.")
